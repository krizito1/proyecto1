<footer class="footer text-lg-start bg-primary bg-gradient mt-auto">
    <div class="container text-md-start pt-2 pb-1">
        <!-- Grid row -->
        <div class="row mt-3">
            <!-- Grid column -->
            <div class="col-12 col-lg-3 col-sm-12 mb-2">
                <!-- Content -->
                <p class="text-white h3">
                    DIANA'S SPORT
                </p>
                <p class="mt-1 text-white">
                    &copy; 2024 Copyright: <a href="https://www.instagram.com/kr1z1t0/" target="_blank" class="text-white">KRIZ</a>
                </p>
            </div>
            <!-- Grid column -->
        </div>
        <!-- Grid row -->
    </div>
</footer>